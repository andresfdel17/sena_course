<?php

echo "Andrés Felipe Delgado <br/>", 1094952560 ,"<br/>Buena tarde profe, como ya había dicho mi sistema no es windows por lo tanto mi entrono de desarrollo es distinto";
